import { Sale } from './sale';

describe('Sale', () => {
  it('should create an instance', () => {
    expect(new Sale()).toBeTruthy();
  });
});
