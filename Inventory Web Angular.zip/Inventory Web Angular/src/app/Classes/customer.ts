export class Customer {
    customerId!:number;
    customerName!:string;
    customerEmail!:string;
    customerPhoneNo!:number;
    customerAddress!:string;
    customerPassword!:string;
}
